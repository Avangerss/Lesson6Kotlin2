interface Buyable {
    fun buy(productId: Int, user: User)
}
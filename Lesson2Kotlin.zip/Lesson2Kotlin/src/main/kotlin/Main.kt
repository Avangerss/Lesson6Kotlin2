fun main(args: Array<String>) {
    val store = Storew()

    val user = User("Даниэль", "ул. Пачтовая, 123").apply {
        balance += 50000
    }

    val scanner = java.util.Scanner(System.`in`)

    println("Все товары в магазине:")
    with(store) {

        printAllProducts()

        print("Введите ID товара, который вы хотите купить: ")
        val productId = scanner.nextInt()

        buy(productId, user)
    }

//    with(store) {
//        printAllProducts()
//    }
}
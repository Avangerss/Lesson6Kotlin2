data class User(
    var userName: String,
    var email: String,
    var age: Int,
    var password: Int
):Verifable{
    override fun verify(user: User) {
        if (this == user) {
            println("Вход был успешно!")
        } else{
            throw IllegalAccessException("Неверныйе данные для входа!")
        }
    }
}


interface Verifable {
    fun verify(user: User)
}